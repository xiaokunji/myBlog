package com.example.demo.entity;

/**
 * 使用帮助实体类
 * 
 * @author xkj
 *
 */
public class HelpInfo  {

	/** 帮助ID */
	private String id;
	/** 帮助编码 */
	private String helpNo;
	/** 帮助内容 */
	private String content;
	/** 帮助标题 */
	private String title;
	/** 创建人ID */
	private String createID;
	/** 创建人名称 */
	private String createName;
	/** 修改人ID */
	private String updateID;
	/** 修改人名称 */
	private String updateName;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getHelpNo() {
		return helpNo;
	}

	public void setHelpNo(String helpNo) {
		this.helpNo = helpNo;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getCreateID() {
		return createID;
	}

	public void setCreateID(String createID) {
		this.createID = createID;
	}

	public String getCreateName() {
		return createName;
	}

	public void setCreateName(String createName) {
		this.createName = createName;
	}

	public String getUpdateID() {
		return updateID;
	}

	public void setUpdateID(String updateID) {
		this.updateID = updateID;
	}

	public String getUpdateName() {
		return updateName;
	}

	public void setUpdateName(String updateName) {
		this.updateName = updateName;
	}

}
