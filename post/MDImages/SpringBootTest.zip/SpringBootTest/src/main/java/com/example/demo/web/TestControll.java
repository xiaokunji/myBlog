package com.example.demo.web;

import java.time.LocalDateTime;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.dao.IHelpDao;
import com.example.demo.entity.HelpInfo;

@RestController
@RequestMapping("/test")
public class TestControll {

	private static Logger logger = LoggerFactory.getLogger(TestControll.class);
	
	@Autowired
	private IHelpDao helpDao;
	
	@RequestMapping("hello")
	public String hello() {
		logger.info("这是hello!!");
		return "hello !! this is hello function";
	}
	
	@RequestMapping("date")
	public LocalDateTime getCurrDate() {
		LocalDateTime now = LocalDateTime.now();
		logger.info("当前时间:{}",now);
		return now;
	}
	
	@RequestMapping("getHelpById")
	public HelpInfo getHelpByid(String id) {
		HelpInfo helpInfo = helpDao.queryHelpById(id);
		logger.info("帮助信息:{}",helpInfo);
		return helpInfo;
	}
	
	@RequestMapping("getHelp")
	public List<HelpInfo> getHelp( ) {
		List<HelpInfo> helpInfos = helpDao.queryHelp();
		logger.info("帮助信息:{}",helpInfos);
		return helpInfos;
	}
}
